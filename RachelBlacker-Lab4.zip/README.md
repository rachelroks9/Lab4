# Lab4

We were instructed to create a new  HTML, JSON, and JavaScript file to all link to one another to create a final product that is looks like our lab 2 final product. However, in this lab, we were to use a given image of a CD and make it so that when the user clicks on it, our work will show.

The HTML uses unordered lists to refer to the text in the JSON file. I used dividers to divide up each section of the page into information relating to the songs. For instance albumn name is a divider because that section of the HTML only includes albumn names.

The validated JSON is read in the JavaScript file and jQuery functions are used to iterate through the items to display them. Each of the variables start with the header of the columns. 